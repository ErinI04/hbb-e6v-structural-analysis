# HBB E6V: sequence alignment and AlphaFold structural comparison

MSBD 502 project comparing wild-type human HBB and the E6V sickle-cell variant using Biopython and ColabFold rank-1 predictions. The supplied ColabFold ZIP archives are the source data; this analysis does **not** run AlphaFold again.

## Quick start

1. Install Python 3.11+.
2. Download or clone this repository, then open a terminal in its root folder.
3. (Optional) Create a virtual environment: `python -m venv .venv` and activate it.
4. Install dependencies: `python -m pip install -r requirements.txt`.
5. Run: `python src/analyze.py`.
6. Inspect `results/summary.json`, `results/rank_confidence.csv`, and PNG figures.

## Inputs

- `data/HBB_WildType_639b6_0.result.zip`: ColabFold WT HBB prediction archive (five models).
- `data/HBB_E6V_Mutant_b4a43.result.zip`: ColabFold E6V HBB prediction archive (five models).
- `data/HBB_E6V_Mutant.fasta`: supplied mutant amino acid sequence.
- Reference sequence: UniProt P68871, https://www.uniprot.org/uniprotkb/P68871/entry
- Experimental structural context: RCSB 2HHB, https://www.rcsb.org/structure/2HHB (not an E6V prediction).

## Analysis choices

- Residue numbering: 147-residue precursor E7V equals mature beta-globin E6V.
- Global alignment: Biopython PairwiseAligner, BLOSUM62, gap-open −10, gap-extend −0.5.
- Structures: rank-1 unrelaxed PDB models for both variants; 147 matched C-alpha atoms.
- RMSD: least-squares optimal superposition with Biopython Superimposer, reported in Å.
- Confidence: ColabFold per-residue pLDDT from score JSON. Five-rank mean scores are also exported.
- No hypothesis test or error bars are appropriate for these deterministic two-sequence comparisons; rank-to-rank variability is presented descriptively rather than as a biological confidence interval.

## Files

- `src/analyze.py`: fully reproducible analysis and matplotlib figures.
- `results/`: generated plots, summary statistics, rank scores, extracted rank models.
- `requirements.txt`: tested environment package versions.
- `data/`: original ColabFold results.

## Caveats

Monomeric AlphaFold predictions cannot model deoxygenated hemoglobin tetramers or HbS polymerization. pLDDT does not measure pathogenicity. The earlier PyMOL console output of 112.827 Å has not been reproduced; this script independently calculates a superimposed rank-1 Cα RMSD of 0.070665 Å.

## Sharing

The professor asks for a **jointly owned group GitHub repository**, shared before the deadline. Add your partner as a collaborator under GitHub repository Settings → Collaborators, and share the repository URL with your instructor. Each partner must submit their own independently written report.
